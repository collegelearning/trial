import os
from flask import Flask, render_template, request, send_from_directory
from docx import Document

app = Flask(__name__)

# Use a raw string to avoid invalid escape sequence warnings
UPLOAD_FOLDER = r'D:/col/generated_docs'  # or use forward slashes
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def get_next_filename():
    """Returns the next available filename with an incremented number."""
    doc_files = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith(".doc") and f.split('.')[0].isdigit()]
    if doc_files:
        last_file = max(doc_files, key=lambda x: int(x.split('.')[0]))
        next_number = int(last_file.split('.')[0]) + 1
    else:
        next_number = 1
    return f"{next_number}.doc"

# This route serves the home page
@app.route('/')
def index():
    return render_template('index.html')  # This will render the index.html template

@app.route('/create_doc', methods=['POST'])
def create_doc():
    # Collect input from form fields
    field_a = request.form.get('field_a')
    field_b = request.form.get('field_b')
    field_c = request.form.get('field_c')
    field_d = request.form.get('field_d')
    field_e = request.form.get('field_e')

    # Create a new Word document
    doc = Document()
    doc.add_paragraph(f'Field A: {field_a}')
    doc.add_paragraph(f'Field B: {field_b}')
    doc.add_paragraph(f'Field C: {field_c}')
    doc.add_paragraph(f'Field D: {field_d}')
    doc.add_paragraph(f'Field E: {field_e}')

    filename = get_next_filename()
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    doc.save(file_path)

    return filename

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)