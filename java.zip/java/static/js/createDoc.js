document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('docForm');
    const createBtn = document.getElementById('createBtn');
    let fileName = ''; // Variable to hold the file name

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        // Create a FormData object from the form
        const formData = new FormData(form);

        // Send the form data using Fetch API
        fetch('/create_doc', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            fileName = data; // Save the filename
            createBtn.textContent = 'Message Already Created'; // Change button text

            // Open the document immediately after creation
            window.open(`/download/${fileName}`, '_blank'); // Open the file
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    createBtn.addEventListener('click', function() {
        if (fileName) {
            // If file already exists, open it instead of creating a new one
            window.open(`/download/${fileName}`, '_blank'); // This will open the existing file
        }
    });
});
